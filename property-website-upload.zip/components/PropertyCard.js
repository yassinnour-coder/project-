import Link from 'next/link'

export default function PropertyCard({ property }) {
  return (
    <Link href={`/property/${property.id}`}>
      <div className="border p-4 rounded hover:shadow-md cursor-pointer">
        <img src={property.image} alt={property.name} className="w-full h-40 object-cover mb-2 rounded" />
        <h2 className="text-xl font-semibold">{property.name}</h2>
        <p className="text-gray-600">{property.location}</p>
        <p className="text-green-700 font-bold">${property.price}</p>
      </div>
    </Link>
  )
}