import { useRouter } from 'next/router'
import properties from '../../data/properties.json'

export default function PropertyDetail() {
  const router = useRouter()
  const { id } = router.query
  const property = properties.find(p => p.id.toString() === id)

  if (!property) return <p>Property not found</p>

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">{property.name}</h1>
      <img src={property.image} alt={property.name} className="w-full h-80 object-cover rounded mb-4" />
      <p><strong>Location:</strong> {property.location}</p>
      <p><strong>Price:</strong> ${property.price}</p>
      <p className="mt-4">{property.description}</p>
    </div>
  )
}